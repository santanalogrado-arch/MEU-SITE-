# CALMI — GUIA COMPLETO DE IMPLEMENTAÇÃO
### Do zero ao ar. Do site ao movimento. Do canal à comunidade.
*Seu roadmap definitivo — tudo que você precisa saber e ninguém te conta de graça.*

---

## ANTES DE TUDO: A MENTALIDADE CERTA

Você não está "criando um site". Você está construindo um **ecossistema de confiança**.
O site é o quartel-general. O conteúdo é o combustível. A lista de emails é o seu ativo mais valioso. A comunidade é o destino.

Tudo se alimenta. Tudo converge. Nada existe isolado.

---

# FASE 1 — FUNDAÇÃO (Semanas 1–2)
*Faça isso antes de publicar qualquer coisa.*

---

## 1.1 REGISTRO DO NOME (PRIORIDADE MÁXIMA)

### Domínio
- Acesse: **registro.br** (domínio .com.br) ou **namecheap.com** (.com)
- Registre: `calmi.com.br` e `calmi.com` (os dois, se possível)
- Custo: ~R$40/ano (.com.br) | ~US$12/ano (.com)
- **Faça hoje.** Domínios somem.

### Redes sociais — registre TUDO agora
Mesmo que não use ainda. Nome disponível hoje pode sumir amanhã.
- [ ] @calmi no Instagram
- [ ] @calmioficial no TikTok
- [ ] @calmi no YouTube
- [ ] @calmi no Pinterest (importante para saúde mental — muito tráfego feminino)
- [ ] calmi@gmail.com ou contato@calmi.com.br
- [ ] Perfil no Linktree (linktr.ee/calmi) — link único para bio

### INPI — Registro de Marca
- Site: **gov.br/inpi**
- Registre "Calmi" nas classes: 41 (educação/conteúdo) e 44 (saúde)
- Custo: ~R$355 por classe para MEI/ME
- **Por que agora:** se viralizar sem marca registrada, alguém registra antes de você.

---

## 1.2 ESTRUTURA JURÍDICA E FINANCEIRA

### Abertura de CNPJ
- Abra um **MEI** se faturar até R$81mil/ano (gratuito, rápido)
- Site: **gov.br/empresas-e-negocios/pt-br/empreendedor**
- CNAE recomendado: 7490-1/04 (atividades de intermediação e agenciamento de serviços)
- Com CNPJ você emite nota, abre conta PJ, vende produtos digitais legalmente

### Conta bancária PJ
- **Nubank PJ** ou **Inter PJ** — gratuitas, sem taxa
- Separe finanças pessoais das do Calmi desde o primeiro dia

### Ferramenta de pagamento
- **Hotmart** (para e-books, cursos, comunidade paga) — sem mensalidade, cobra % por venda
- **Kiwify** (alternativa brasileira, ótima para infoprodutos)
- **Stripe** (para pagamentos internacionais futuramente)

---

## 1.3 EMAIL PROFISSIONAL

Nunca use Gmail pessoal para o Calmi.
- **Google Workspace**: ~R$30/mês → contato@calmi.com.br
- **Alternativa gratuita**: Zoho Mail (grátis para 1 usuário)
- Crie: contato@calmi.com.br | eliane@calmi.com.br

---

# FASE 2 — PUBLICAÇÃO DO SITE (Semanas 2–3)

---

## 2.1 HOSPEDAGEM — ONDE COLOCAR O SITE

### Opção A — Iniciante (recomendada para começar)
**Netlify** (netlify.com) — GRATUITO
- Faça upload do arquivo calmi.html
- Conecte seu domínio
- SSL (https) automático e gratuito
- Zero configuração técnica
- Como fazer: netlify.com → "Add new site" → "Deploy manually" → arraste o arquivo

### Opção B — Profissional
**Hostinger** — ~R$12/mês
- Hospedagem + email + domínio em um lugar
- Painel simples, suporte em português

### Opção C — Sem mexer em código nunca mais
**Webflow** ou **Framer** — a partir de US$14/mês
- Edite o site visualmente, sem código
- Ideal quando quiser expandir o site

---

## 2.2 CONFIGURAÇÕES OBRIGATÓRIAS DO SITE

### SSL/HTTPS
- Obrigatório para segurança e Google
- Netlify e Hostinger fazem automaticamente

### Velocidade
- Imagens: sempre use formato WebP, máximo 200kb
- Ferramenta grátis: squoosh.app
- Teste de velocidade: pagespeed.web.dev (mire score >80)

### Páginas que o site PRECISA ter
Além da home (que já está pronta), crie:
- [ ] **/privacidade** — Política de Privacidade (obrigatório por lei)
- [ ] **/termos** — Termos de Uso
- [ ] **/obrigada** — Página após cadastro na newsletter (crucial para conversão)
- [ ] **/links** — Página de links para a bio do Instagram

### Analytics — saiba quem visita
- **Google Analytics 4** — gratuito, instale no dia 1
- Site: analytics.google.com → crie propriedade → copie o código → cole antes do </head> do site
- **Microsoft Clarity** — gratuito, mostra gravações reais de usuários no site (ouro puro)
- Site: clarity.microsoft.com

---

## 2.3 POLÍTICA DE PRIVACIDADE E LGPD

**A LGPD (Lei 13.709/2018) se aplica a você desde o primeiro visitante.**

### O que você precisa ter:

**1. Política de Privacidade** — publique em calmi.com.br/privacidade
Deve conter:
- Quais dados coleta (nome, email, comportamento no site)
- Por que coleta (enviar newsletter, melhorar o site)
- Com quem compartilha (Mailchimp, Google Analytics, etc.)
- Por quanto tempo guarda
- Como o usuário pode pedir exclusão: contato@calmi.com.br
- Quem é a controladora dos dados: seu nome + CNPJ

**2. Cookie Banner**
- Já está no site — mas precisa que o usuário realmente possa recusar
- Ferramenta gratuita: Cookiebot (tier gratuito para sites pequenos)

**3. Consentimento explícito na newsletter**
- Checkbox desmarcado por padrão: "Concordo em receber emails do Calmi"
- NUNCA adicione pessoas à lista sem permissão
- Guarde o registro de quando cada pessoa deu consentimento (o Mailchimp faz isso automaticamente)

**4. Direitos do titular**
- Qualquer pessoa pode pedir: acesso, correção, exclusão dos dados
- Responda em até 15 dias
- Tenha um email dedicado: privacidade@calmi.com.br

**Gerador gratuito de Política de Privacidade:** privacidade.com.br

---

# FASE 3 — LISTA DE EMAILS (O ATIVO MAIS VALIOSO)

*Instagram pode te banir. TikTok pode sumir. Sua lista de emails é sua para sempre.*

---

## 3.1 FERRAMENTA DE EMAIL MARKETING

### Recomendação: **Mailchimp**
- Gratuito até 500 contatos e 1.000 emails/mês
- Fácil de usar, integra com tudo
- Site: mailchimp.com

### Alternativa brasileira: **E-goi** ou **LeadLovers**
- Suporte em português, servidores no Brasil (melhor para LGPD)

### Quando crescer: **ConvertKit** (agora Kit)
- Melhor para criadores de conteúdo
- Automações poderosas, ~US$25/mês

---

## 3.2 COMO INTEGRAR O FORMULÁRIO DO SITE

No Mailchimp:
1. Crie uma "Audience" (lista) chamada "Calmi — Newsletter"
2. Vá em "Embedded forms" → copie o link da API
3. No site, substitua o `<form>` pelo código do Mailchimp
4. Configure a página de obrigada: calmi.com.br/obrigada

---

## 3.3 ESTRATÉGIA DE LISTA — O QUE NINGUÉM TE CONTA

### O segredo: nunca peça o email. Ofereça algo em troca.

**Lead magnets** (iscas digitais) para o Calmi:
- [ ] **"5 sinais de que você está em burnout"** — PDF de 1 página
- [ ] **"Diário do Autocuidado"** — PDF para imprimir, 7 dias
- [ ] **"O teste da cuidadora"** — quiz que mostra seu nível de esgotamento
- [ ] **"3 exercícios de respiração para quando tudo aperta"** — áudio ou PDF
- [ ] **"Lista de espera do livro A Morte da Heroína"** — exclusividade cria urgência

### Sequência de boas-vindas (automática, configure no Mailchimp)
- **Email 1** (imediato): "Você chegou. Finalmente." — entrega o material + apresentação pessoal
- **Email 2** (dia 3): Sua história — por que criou o Calmi
- **Email 3** (dia 7): O melhor conteúdo do canal até agora
- **Email 4** (dia 14): Convite para a comunidade (quando existir)

### Frequência após sequência
- 1 email por semana, toda terça-feira às 8h
- Formato: 1 reflexão + 1 ferramenta prática + 1 link do canal
- Máximo 400 palavras — respeite o tempo delas

---

# FASE 4 — CONTEÚDO E ALGORITMO

---

## 4.1 ESTRATÉGIA DE CONTEÚDO POR PLATAFORMA

### YouTube (prioridade 1)
**Por que:** Conteúdo indexado no Google. Vídeo de 2 anos ainda traz inscritos. Algoritmo premia consistência.

**Formato ideal para saúde mental:**
- Vídeos de 8–15 minutos (tempo médio de atenção do público feminino adulto)
- Faceless funciona: voz + slides + b-roll de natureza/cotidiano
- Thumbnail: fundo simples, texto grande, cor da paleta Calmi

**Frequência:** 1 vídeo por semana (mesmo dia, mesma hora)
**Melhor dia:** terça ou quarta, publicar às 9h

**Títulos que performam para seu nicho:**
- "X sinais de que você está em burnout (e não sabe)"
- "Por que dizer não é um ato de amor (e não egoísmo)"
- "O que é codependência e como sair dela"
- "Você não é responsável pela felicidade de ninguém"

**SEO YouTube:**
- Pesquise palavras-chave em: vidiq.com (grátis) ou tubics.com
- Coloque a palavra-chave nos primeiros 3 segundos do vídeo
- Descrição: mínimo 300 palavras com palavras-chave naturais

---

### Instagram (prioridade 2)
**Formatos que funcionam para saúde mental em 2025:**
- **Carrosséis** (6–10 slides): maior salvamento, maior alcance
- **Reels de 30–60s**: maior alcance para novos seguidores
- **Stories diários**: fidelização de quem já te segue

**Frequência:** 3–4 posts/semana + stories diários

**Conteúdo que salva (= sinal positivo pro algoritmo):**
- Listas ("7 frases que toda cuidadora precisa ouvir")
- Ferramentas práticas ("Como respirar quando a ansiedade aperta")
- Reflexões que validam a experiência delas

**Hashtags:** use no primeiro comentário, não na legenda
Misture: grandes (#saudemental 2M+), médias (#cuidadoradefamilia 50k) e pequenas (#calmi)

---

### TikTok (prioridade 3)
**Faceless funciona muito:** voz + texto na tela + música ambiente
**Duração ideal:** 45–90 segundos
**Frequência:** 5–7 vídeos/semana (o algoritmo do TikTok premia volume)
**Gancho nos primeiros 2 segundos:** "Se você cuida de todo mundo menos de você, isso é pra você"

---

### Pinterest (bônus — poucos fazem, alto retorno)
- Crie pins de cada carrossel do Instagram
- Tráfego feminino, 40+ anos, alta intenção
- Posts duram anos (ao contrário do Instagram)
- Ferramenta: Canva → templates de pin → salve como imagem

---

## 4.2 CALENDÁRIO DE CONTEÚDO — MODELO SEMANAL

| Dia | Plataforma | Formato | Tema |
|-----|-----------|---------|------|
| Segunda | Instagram | Story | Pergunta para engajar |
| Terça | YouTube | Vídeo 10min | Tema principal da semana |
| Terça | Email | Newsletter | Reflexão + link do vídeo |
| Quarta | Instagram | Carrossel | Conteúdo educativo |
| Quinta | TikTok | Reels 60s | Recorte do vídeo do YouTube |
| Sexta | Instagram | Reels | Versão curta do tema da semana |
| Sábado | Instagram | Story | Bastidores / pessoal |

---

## 4.3 REAPROVEITAMENTO DE CONTEÚDO (trabalhe uma vez, publique dez)

```
1 VÍDEO YOUTUBE (15min)
      ↓
Transcrição → Artigo de blog (SEO Google)
      ↓
3 Recortes → Reels Instagram + TikTok
      ↓
5 frases → Posts simples Instagram
      ↓
1 Carrossel → Slides do tema principal
      ↓
1 Pin → Pinterest
      ↓
Resumo → Newsletter da semana
```

**Ferramenta:** **Opus Clip** (grátis parcial) — corta automaticamente os melhores trechos do vídeo

---

# FASE 5 — MONETIZAÇÃO

*Não é sobre ganhar dinheiro. É sobre ter sustentabilidade para continuar entregando valor.*

---

## 5.1 ESCADA DE VALOR DO CALMI

```
GRATUITO                    PAGO
   │                          │
   ▼                          ▼
Conteúdo             Lead Magnet (PDF)
YouTube/IG/TT             (grátis)
                             │
                             ▼
                      Newsletter
                        (grátis)
                             │
                             ▼
                    E-book / Workbook
                       (R$27–97)
                             │
                             ▼
                    Comunidade Calmi
                    (R$47–97/mês)
                             │
                             ▼
                  Livro "A Morte da Heroína"
                       (R$49–89)
                             │
                             ▼
                    Curso / Programa
                      (R$297–997)
```

---

## 5.2 PRODUTO 1 — E-BOOK (lance em 30–60 dias)

**Sugestão:** "Guia da Cuidadora Consciente" — R$37
- 30–50 páginas no Canva (grátis)
- Venda na Hotmart (zero custo inicial)
- Promova para sua lista de emails primeiro

---

## 5.3 PRODUTO 2 — COMUNIDADE CALMI (lance em 3–6 meses)

**Plataforma:** Hotmart Sparkle, Kiwify, ou Circle.so
**Modelo:** assinatura mensal — R$47 a R$97/mês
**O que incluir:**
- Grupo fechado (sem WhatsApp — você perde o controle)
- Aula ou conteúdo exclusivo mensal
- Encontros ao vivo mensais (Google Meet)
- Diário coletivo, desafios semanais

**Como lançar:**
1. Anuncie lista de espera 30 dias antes
2. Abra para lista de espera com desconto de fundadoras
3. Limite as primeiras vagas (escassez real — você não consegue atender 500 de início)

---

## 5.4 PRODUTO 3 — O LIVRO (médio prazo, 6–12 meses)

**Opções:**
- **Autopublicação:** KDP Amazon (grátis, você fica com 70% das vendas)
- **Físico:** Edição independente via gráfica (mínimo 100 unidades)
- **E-book:** Hotmart (lançamento com afiliados)

**A lista de emails que você construiu É o seu público de lançamento.**
1.000 pessoas na lista = em média 30–50 vendas no lançamento.

---

## 5.5 OUTRAS FONTES DE RECEITA

- **Afiliações**: produtos de saúde mental, meditação, livros — recomende o que usa
  - Amazon Afiliados: afiliados.amazon.com.br
  - Hotmart Afiliados: produtos de outros criadores na área
- **Parcerias/Publipost**: quando tiver 5–10k seguidores
- **Mentoria individual**: atendimento 1:1 (se tiver formação na área)
- **Palestras**: empresas pagam bem por conteúdo de saúde mental corporativa

---

# FASE 6 — SEO E TRÁFEGO ORGÂNICO

---

## 6.1 SEO PARA O SITE

**Palavras-chave para ranquear (pesquise no Google o que as pessoas buscam):**
- "burnout cuidadora"
- "como parar de ser codependente"
- "saúde mental mulher"
- "autocuidado para mães"
- "limites saudáveis relacionamento"

**Ferramentas gratuitas:**
- **Google Search Console**: veja como o Google vê seu site (search.google.com/search-console)
- **Ubersuggest**: pesquisa de palavras-chave em português (grátis parcial)
- **Answer The Public**: o que as pessoas perguntam sobre seus temas

**Blog no site (quando estiver pronta)**
- 1 artigo por mês de 1.000+ palavras
- Use o conteúdo do YouTube transcrito e expandido
- Cada artigo = uma porta de entrada pelo Google

---

## 6.2 GOOGLE MEU NEGÓCIO

- Gratuito
- Crie um perfil em: business.google.com
- Aparece quando buscam "Calmi" ou "saúde mental" na sua região
- Adicione: descrição, link do site, redes sociais

---

# FASE 7 — FERRAMENTAS ESSENCIAIS (maioria grátis)

---

## 7.1 KIT COMPLETO DO CALMI

| Função | Ferramenta | Custo |
|--------|-----------|-------|
| Site | Netlify | Grátis |
| Email profissional | Zoho ou Google Workspace | Grátis / R$30/mês |
| Email marketing | Mailchimp | Grátis até 500 |
| Design | Canva Pro | R$55/mês (vale muito) |
| Edição de vídeo | CapCut | Grátis |
| Gravação | OBS Studio | Grátis |
| Subtítulas automáticas | CapCut / Submagic | Grátis |
| Agendamento redes | Later ou Buffer | Grátis até 10 posts |
| Link na bio | Linktree | Grátis |
| Analytics | Google Analytics 4 | Grátis |
| Comportamento usuário | Microsoft Clarity | Grátis |
| SEO YouTube | VidIQ | Grátis parcial |
| Recorte automático | Opus Clip | Grátis parcial |
| Venda de produtos | Hotmart | % por venda |
| Senhas seguras | Bitwarden | Grátis |
| Backup | Google Drive | 15GB grátis |

---

# FASE 8 — SEGURANÇA E PROTEÇÃO DE DADOS

---

## 8.1 SEGURANÇA DIGITAL

### Senhas
- Use um gerenciador: **Bitwarden** (grátis, open source)
- Nunca reutilize senhas
- Ative autenticação em 2 fatores em tudo (2FA): Instagram, Google, Hotmart

### Backup
- Site: faça download do HTML semanalmente
- Conteúdo: Google Drive + HD externo (regra 3-2-1: 3 cópias, 2 mídias, 1 fora de casa)
- Lista de emails: exporte CSV do Mailchimp mensalmente

### Email profissional
- Nunca clique em links suspeitos
- Use o email profissional só para o Calmi
- Ative alertas de login no Google

---

## 8.2 PROTEÇÃO DE CONTEÚDO

- Coloque © 2025 Calmi em todo conteúdo
- Watermark (marca d'água) discreta nas imagens
- Se alguém copiar seu conteúdo: denúncia pelo próprio Instagram/YouTube (formulário de direitos autorais)
- Registre seus textos mais importantes na Biblioteca Nacional: bn.gov.br (R$20 por obra)

---

## 8.3 LGPD — CHECKLIST COMPLETO

- [ ] Política de Privacidade publicada e acessível
- [ ] Cookie banner funcionando (usuário pode recusar)
- [ ] Formulários com checkbox de consentimento
- [ ] Email de privacidade: privacidade@calmi.com.br
- [ ] Dados de analytics anonimizados (configurar no GA4)
- [ ] Contrato com fornecedores que tratam dados (Mailchimp, Google — aceitar termos de processador)
- [ ] Prazo de retenção de dados definido (ex: guardo emails por 2 anos após descadastro)
- [ ] Processo documentado para atender requisições de titulares

---

# FASE 9 — ROADMAP COMPLETO

---

## CRONOGRAMA RECOMENDADO

### MÊS 1 — FUNDAÇÃO
- [ ] Registrar domínio calmi.com.br
- [ ] Registrar @ em todas as redes
- [ ] Abrir MEI
- [ ] Publicar site no Netlify
- [ ] Configurar Google Analytics + Clarity
- [ ] Criar conta Mailchimp
- [ ] Publicar Política de Privacidade
- [ ] Criar email profissional
- [ ] Criar 1 lead magnet (PDF simples)
- [ ] Gravar e publicar os primeiros 2 vídeos no YouTube

### MÊS 2 — TRAÇÃO
- [ ] Estabelecer rotina de conteúdo (seguir o calendário semanal)
- [ ] Chegar a 100 inscritos na lista de email
- [ ] Criar Linktree com todos os links
- [ ] Otimizar site para SEO (Google Search Console)
- [ ] Criar Pinterest e começar a repurposear conteúdo
- [ ] Iniciar protocolo de reaproveitamento de conteúdo

### MÊS 3 — MONETIZAÇÃO INICIAL
- [ ] Lançar e-book / workbook (R$37–97)
- [ ] Abrir lista de espera da Comunidade Calmi
- [ ] Anunciar o livro "A Morte da Heroína"
- [ ] Atingir 500 pessoas na lista de email

### MÊS 4–6 — ESCALA
- [ ] Lançar Comunidade Calmi (primeiras 50 vagas)
- [ ] Considerar tráfego pago (Meta Ads) — R$20/dia já funciona
- [ ] Primeiro webinar ou live para a comunidade
- [ ] Parcerias com outros criadores no nicho

### MÊS 7–12 — CONSOLIDAÇÃO
- [ ] 2.000+ pessoas na lista de email
- [ ] Lançamento do livro
- [ ] Programa ou curso estruturado
- [ ] Presença em podcasts do nicho (pauta gratuita, exposição enorme)
- [ ] Avaliar patrocínios e parcerias comerciais

---

# FASE 10 — O QUE MUDA O JOGO (o que ninguém te conta)

---

## 10.1 A REGRA DE OURO DO CONTEÚDO

**80% do conteúdo: gratuito, generoso, transformador.**
**20% do conteúdo: comercial.**

Quem só vende, perde a audiência.
Quem só dá, não sustenta o projeto.
O equilíbrio é o negócio.

---

## 10.2 SEU MAIOR ATIVO NÃO É O SITE

É a sua VOZ. Sua história. Seu ângulo único.

Existem mil canais de saúde mental. Não existe outra você.
O que te diferencia não é o tema — é o seu lugar de fala, sua experiência, sua forma de dizer.

**Nunca terceirize sua voz.**

---

## 10.3 A COMUNIDADE VEM ANTES DO PRODUTO

Antes de criar qualquer produto pago:
1. Construa a lista de emails
2. Ouça o que as pessoas pedem
3. Crie O QUE ELAS PEDIRAM

O produto que você acha que elas precisam nem sempre é o que elas vão comprar.
O produto que elas pediram já tem comprador antes de existir.

---

## 10.4 CONSISTÊNCIA VENCE VIRALIZAÇÃO

1 post viral não constrói negócio.
52 semanas de conteúdo consistente constroem autoridade.

A pergunta não é "como viralizo?"
A pergunta é "como mantenho por 1 ano?"

Resposta: Crie sistemas, não dependa de inspiração.
- Template de roteiro pronto
- Dia fixo de gravação
- Calendário feito com 2 semanas de antecedência

---

## 10.5 EMAIL > SEGUIDOR

10.000 seguidores no Instagram = ~150 pessoas veem seu post (algoritmo)
1.000 pessoas na lista de email = ~250 pessoas abrem seu email (25% de taxa de abertura)

**A lista de emails é mais valiosa que os seguidores.**

---

## 10.6 MÉTRICAS QUE IMPORTAM DE VERDADE

Esqueça curtidas. Acompanhe:
- **Taxa de abertura de email** (meta: >25%)
- **Taxa de clique no email** (meta: >3%)
- **Tempo médio no site** (meta: >2 minutos)
- **Taxa de conversão do formulário** (meta: >3%)
- **Crescimento da lista por semana**
- **Receita por assinante de email** (benchmark: R$1–3/mês)

---

## 10.7 PARCERIAS ESTRATÉGICAS (alavancagem gratuita)

- **Apareça em podcasts** do nicho: escreva para apresentadores, ofereça pauta gratuita
- **Collab com criadores** que atendem o mesmo público mas não competem (ex: nutricionista, coach de carreira feminina)
- **Responda comentários** dos maiores canais do seu nicho — presença constrói audiência
- **Seja entrevistada** em grupos de Facebook/WhatsApp do nicho

---

# RESUMO EXECUTIVO — PRIMEIROS 30 DIAS

1. **Hoje:** Registrar domínio + redes sociais
2. **Esta semana:** Publicar site no Netlify + Política de Privacidade
3. **Esta semana:** Criar conta Mailchimp + integrar formulário
4. **Esta semana:** Criar lead magnet (PDF no Canva)
5. **Semana 2:** Gravar primeiros 2 vídeos + publicar no YouTube
6. **Semana 2:** Instagram: 3 posts + stories diários
7. **Semana 3:** TikTok: recortes dos vídeos do YouTube
8. **Semana 4:** Primeira newsletter para lista
9. **Mês 1:** 100 pessoas na lista. Essa é a meta. Só essa.

---

*O Calmi não é um projeto. É um movimento.*
*Cada mulher que você alcança, alcança outras.*
*Comece imperfeita. Melhore em público. Nunca pare.*

---

**© 2025 Calmi — Documento de uso interno. Todos os direitos reservados.**
